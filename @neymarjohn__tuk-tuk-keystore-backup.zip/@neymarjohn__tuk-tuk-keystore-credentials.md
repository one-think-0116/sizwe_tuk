# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: ead6505908b247748b0bf1207889e1c2
- Android key alias: QG5leW1hcmpvaG4vdHVrLXR1aw==
- Android key password: 2c89c99706d14e6aaea9610906330f9b
      